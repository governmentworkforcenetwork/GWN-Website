GOVERNMENT WORKFORCE NETWORK LLC
Website Build Guide
--------------------------------------
Founded 2025 — Together, Protecting and Promoting Employee Well-Being.

HOW TO USE:
1) Upload the entire folder to Netlify (or zip and upload).
2) Replace images in /img with your final PNGs, keeping these filenames:
   - logo.png
   - hero.png
   - volunteer.png
   - country-directors.png
   - glow-grow.png
   - professional-growth.png
   - sip-serve.png
   - recognition-galas.png
   - sponsors.png
3) Edit text in index.html if needed.
